﻿using System;
using System.IO;
using System.Windows;

namespace GrabiT
{
    internal class ConfigEdit
    {
        static string configFilePath = MainWindow.configFilePath;

        // int
        #region
        // Schreibt/Erstellt einen int an Mitgegebener stelle 
        public static void WriteInt(string where, int value)
        {
            try
            {
                string[] lines = File.ReadAllLines(configFilePath);

                for (int i = 0; i < lines.Length; i++)
                {
                    if (lines[i].StartsWith(where))
                    {
                        lines[i] = where + value;
                        File.WriteAllLines(configFilePath, lines);
                        return;
                    }
                }

                // Wenn "where" nicht gefunden wurde, füge es am Ende der Datei hinzu
                using (StreamWriter writer = new StreamWriter(configFilePath, true)) // ChatGPT
                {
                    writer.WriteLine(where + value);
                }
            }
            catch (Exception ex) { ex.ToString(); }
        }

        // Lest einen int an der Mitgegebenen stelle
        public static int ReadInt(string where, int defaultValue)
        {
            int value = defaultValue;

            try
            {
                using (StreamReader reader = new StreamReader(configFilePath)) // ChatGPT
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (line.StartsWith(where))
                        {
                            if (int.TryParse(line.Substring(where.Length), out value)) //ChatGPT
                            {
                                return value;
                            }
                        }
                    }
                }

                // Wenn "where" nicht gefunden wurde, füge es am Ende der Datei hinzu
                using (StreamWriter writer = new StreamWriter(configFilePath, true)) // ChatGPT
                {
                    writer.WriteLine(where + defaultValue);
                }
            }
            catch (Exception ex) { ex.ToString(); }
            return defaultValue;
        }
        #endregion

        // double
        #region
        public static void WriteDouble(string where, double value)
        {
            try
            {
                string[] lines = File.ReadAllLines(configFilePath);

                for (int i = 0; i < lines.Length; i++)
                {
                    if (lines[i].StartsWith(where))
                    {
                        lines[i] = where + value;
                        File.WriteAllLines(configFilePath, lines);
                        return;

                    }
                }

                // Wenn "where" nicht gefunden wurde, füge es am Ende der Datei hinzu
                using (StreamWriter writer = new StreamWriter(configFilePath, true)) //ChatGPT
                {
                    writer.WriteLine(where + value);
                }
            }
            catch (Exception ex) { ex.ToString(); }
        }

        // Lest einen int an der Mitgegebenen stelle
        public static double ReadDouble(string where, double defaultValue)
        {
            double value = defaultValue;

            try
            {
                using (StreamReader reader = new StreamReader(configFilePath)) //ChatGPT
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (line.StartsWith(where))
                        {
                            if (double.TryParse(line.Substring(where.Length), out value)) //ChatGPT
                            {
                                return value;
                            }
                        }
                    }
                }

                // Wenn "where" nicht gefunden wurde, füge es am Ende der Datei hinzu
                using (StreamWriter writer = new StreamWriter(configFilePath, true)) //ChatGPT
                {
                    writer.WriteLine(where + defaultValue);
                }
            }
            catch (Exception ex) { ex.ToString(); }
            return defaultValue;
        }
        #endregion

        // string
        #region
        // Schreibt/Erstellt einen string an Mitgegebener stelle 
        public static void WriteString(string where, string value)
        {
            try
            {
                string[] lines = File.ReadAllLines(configFilePath);

                for (int i = 0; i < lines.Length; i++)
                {
                    if (lines[i].StartsWith(where))
                    {
                        lines[i] = where + value;
                        File.WriteAllLines(configFilePath, lines);
                        return;
                    }
                }

                // Wenn "where" nicht gefunden wurde, füge es am Ende der Datei hinzu
                using (StreamWriter writer = new StreamWriter(configFilePath, true)) //ChatGPT
                {
                    writer.WriteLine(where + value);
                }
            }
            catch (Exception ex) { ex.ToString(); }
        }

        // Lest einen int an der Mitgegebenen stelle
        public static string ReadString(string where, string defaultValue)
        {
            string value = defaultValue;

            try
            {
                using (StreamReader reader = new StreamReader(configFilePath)) //ChatGPT
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (line.StartsWith(where))
                        {
                            string[] parts = line.Split('=');
                            value = parts[1];
                            return value;
                        }
                    }
                }

                // Wenn "where" nicht gefunden wurde, füge es am Ende der Datei hinzu
                using (StreamWriter writer = new StreamWriter(configFilePath, true)) //ChatGPT
                {
                    writer.WriteLine(where + defaultValue);
                }
            }
            catch (Exception ex) { ex.ToString(); }
            return defaultValue;
        }
        #endregion

        // bool
        #region

        public static void WriteBool(string where, bool value)
        {
            if (value)
            {
                WriteString(where, "true");
            }
            else
            {
                WriteString(where, "false");
            }
        }

        public static bool ReadBool(string where, bool defaultValue)
        {
            if (defaultValue)
            {
                if (ReadString(where, "true") == "true")
                    return true;
                return false;
            }
            else
            {
                if (ReadString(where, "false") == "true")
                    return true;
                return false;
            }
        }

        #endregion
    }
}
