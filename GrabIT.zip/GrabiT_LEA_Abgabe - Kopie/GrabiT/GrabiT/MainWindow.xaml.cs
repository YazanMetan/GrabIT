﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using Application = System.Windows.Application;
using Button = System.Windows.Controls.Button;
using DataFormats = System.Windows.DataFormats;
using DataObject = System.Windows.DataObject;
using DragDropEffects = System.Windows.DragDropEffects;
using File = System.IO.File;
using Image = System.Windows.Controls.Image;
using MenuItem = System.Windows.Controls.MenuItem;
using MessageBox = System.Windows.MessageBox;
using Path = System.IO.Path;

namespace GrabiT 
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window 
    {
        // Nur die Zeilen die mit ChatGPT oder mit Quelle versehen sind, sind nicht von uns.
        // Bei Mehreren Zeilen wird Anfang und Ende als dieser Kommentiert
        public static readonly string resourcesFolder = "Resources";
        private static bool shouldOpen = false;
        private static bool isWindowOpen = false;
        private static bool mouseInWindow = false;
        private static bool deleteAfterDrag = false;
        private static int gridCells = 8;
        private static int gridSite = 0;
        internal static string configFilePath = "config.txt";
        internal static string fileFolder = SettingsWindow.ReturnFolder();
        private static string tempFolderPath = Path.Combine(Path.GetTempPath(), "GrabiT_Temp_Files");

        private readonly static int maxFileName = 14;

        private static double width = SystemParameters.PrimaryScreenWidth / 5 * SettingsWindow.ReturnScale();
        private static double height = SystemParameters.PrimaryScreenHeight / 6 * SettingsWindow.ReturnScale();

        Watcher watcher = new Watcher(fileFolder);

        internal static LinkedList<SavedFile> filesInList = new LinkedList<SavedFile>();
        internal static LinkedList<Grid> filesInGrid = new LinkedList<Grid>();
        internal static List<SavedFile> filesInFolder = new List<SavedFile>();

        public MainWindow() 
        {
            InitializeComponent();
            watcher.Start();
            Load();
            OpenIfShould();
            RunWindow();
        }

        // Lädt die Aktuellen settings
        #region
        private void Load()
        {
            Width = width; Height = height;
            fileGrid.Height = height; fileGrid.Width = width;
            Top = -height;
            Left = (SystemParameters.PrimaryScreenWidth - width) / 2;
            LoadFiles();
            Directory.CreateDirectory(tempFolderPath);
            Directory.Delete(tempFolderPath, true);
            Directory.CreateDirectory(tempFolderPath);
        }
        public static void ApplyNewSettingsToWindow()
        {
            fileFolder = SettingsWindow.ReturnFolder();
            width = SystemParameters.PrimaryScreenWidth / 5 * SettingsWindow.ReturnScale();
            height = SystemParameters.PrimaryScreenHeight / 6 * SettingsWindow.ReturnScale();
            MainWindow mainWindow = Application.Current.MainWindow as MainWindow;
            mainWindow.Load();
        }
        #endregion

        // File anzeigen
        #region
        // Lädt die aktuellen files
        public static void LoadFiles()
        {
            try
            {
                Application.Current.Dispatcher.Invoke(() => // ChatGPT
                {
                    // Löscht das Aktuelle Grid und Läd denn Ordner Inhatl
                    RemoveGridsFromGrids();
                    int maxGrids = gridSite + gridCells;
                    int filesLength;
                    filesInFolder = new List<SavedFile>();
                    string[] dirsInFolder = Directory.GetDirectories(fileFolder);
                    string[] fileInFolder = Directory.GetFiles(fileFolder);
                    string[] files = new string[dirsInFolder.Length + fileInFolder.Length];

                    for (int i = 0; i < dirsInFolder.Length; i++)
                        files[i] = dirsInFolder[i];
                    for (int i = 0; i < fileInFolder.Length; i++)
                        files[i + dirsInFolder.Length] = fileInFolder[i];



                    foreach (string file in files)
                    {
                        filesInFolder.Add(new SavedFile(file));
                    }

                    // Fügt die Inhalte hinzu die auf der Seite sind
                    if (filesInFolder.Count > maxGrids)
                        filesLength = maxGrids;
                    else 
                        filesLength = filesInFolder.Count;

                    for (int i = gridSite; i < filesLength; i++)
                    {
                        UpdateFiles(files[i]);
                    }

                    // Löscht die inhalte die gelöscht werden sollen
                    List<string> dirsInFolderNew = Directory.GetDirectories(fileFolder).ToList();
                    List<string> filesInFolderNew = Directory.GetFiles(fileFolder).ToList();
                    List<string> allInFolderNew = dirsInFolderNew.Concat(filesInFolderNew).ToList();
                    List<string> filesToRemove = new List<string>();

                    foreach (SavedFile file in filesInList)
                    {
                        if (!allInFolderNew.Contains(file._Path))
                        {
                            filesToRemove.Add(file._Path);
                        }
                    }

                    foreach (string fileToRemove in filesToRemove)
                    {
                        DeleteFile(filesInList.First(f => f._Path == fileToRemove)); // ChatGPT
                    }
                });
            }
            catch (Exception ex)
            {
                // Da lassen weil weirde bugs aber keine Probleme
                MessageBox.Show(ex.Message + " LoadFiles");
            }
        }

        // Entfernt die Grids aus dem Unifromgrid
        private static void RemoveGridsFromGrids()
        {
            MainWindow mainWindow = Application.Current.MainWindow as MainWindow;
            Application.Current.Dispatcher.Invoke(() => // ChatGPT
            {
                foreach (Grid gridToRemove in filesInGrid)
                {
                    mainWindow.fileGrid.Children.Remove(gridToRemove);
                }
                filesInGrid.Clear();
            });
        }

        // Updatet die Dateien die Fenster kommen
        private static void UpdateFiles(string file)
        {
            try
            {
                SavedFile newFile = new SavedFile(file);
                MainWindow mainWindow = Application.Current.MainWindow as MainWindow;

                Application.Current.Dispatcher.Invoke(() => // ChatGPT
                {
                    if (filesInFolder.Contains(newFile) && !filesInList.Contains(newFile) && !mainWindow.DoesGridExistInGrid(newFile))
                    {
                        filesInList.AddLast(newFile);
                        Grid grid = mainWindow.AddFileToGrid(newFile);
                        mainWindow.fileGrid.Children.Add(grid);
                        filesInGrid.AddLast(grid);
                    }
                    else if (filesInFolder.Contains(newFile) && filesInList.Contains(newFile) && !mainWindow.DoesGridExistInGrid(newFile))
                    {
                        Grid grid = mainWindow.AddFileToGrid(newFile);
                        mainWindow.fileGrid.Children.Add(grid);
                        filesInGrid.AddLast(grid);
                    }
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + " AddFile");
            }
        }

        // Löscht eine Datei aus dem Unifromggrid
        private static void DeleteFile(SavedFile fileToKill)
        {
            MainWindow mainWindow = Application.Current.MainWindow as MainWindow;
            try
            {
                filesInList.Remove(fileToKill);
            }
            catch { }

            // Remove the grid associated with the file from filesInGrid
            Grid gridToRemove = mainWindow.FindGridByFilePath(fileToKill._Path);
            if (gridToRemove != null)
            {
                filesInGrid.Remove(gridToRemove);
                mainWindow.fileGrid.Children.Remove(gridToRemove);
            }
        }
        // Sucht das Grid im Unifromgrid anhand des Paths
        private Grid FindGridByFilePath(string filePath)
        {
            foreach (Grid grid in filesInGrid)
            {
                if (grid.Tag != null && grid.Tag.ToString() == filePath)
                {
                    return grid;
                }
            }
            return null; 
        }
        // Überprüft ob ein gird schon erstellt wurde
        private bool DoesGridExistInGrid(SavedFile file)
        {
            try
            {
                // Überprüfen Sie, ob ein Grid mit demselben Path bereits existiert
                foreach (Grid grid in filesInGrid)
                {
                    if (grid.Tag.ToString() == file._Path)
                    {
                        return true;
                    }
                }
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return false;
        }
        #endregion

        // Grid Editing
        #region
        // Fügt ein Gird für die Datein hinzu
        private Grid AddFileToGrid(SavedFile file)
        {
            try
            {
                MainWindow mainWindow = Application.Current.MainWindow as MainWindow;
                Grid grid = new Grid();

                // Erstellt eine Zeile für das Icon
                RowDefinition row1 = new RowDefinition();
                row1.Height = new GridLength(60, GridUnitType.Star); // 60% des Grids
                grid.RowDefinitions.Add(row1);

                // Erstellt eine Zeile für den Dateinamen
                RowDefinition row2 = new RowDefinition();
                row2.Height = new GridLength(1, GridUnitType.Auto);
                grid.RowDefinitions.Add(row2);

                // Erstellt eine Zeile für den Dateityp
                RowDefinition row3 = new RowDefinition();
                row3.Height = new GridLength(1, GridUnitType.Auto);
                grid.RowDefinitions.Add(row3);

                // Erstellt ein Image für das Icon
                Image iconImage = new Image();
                iconImage.Source = file._Icon;
                iconImage.HorizontalAlignment = HorizontalAlignment.Center;

                // Erstellt ein TextBlock-Element für den Dateinamen
                string newFileName = file._Name;
                if (file._Name.Length > maxFileName)
                    newFileName = file._Name.Substring(0, maxFileName);
                TextBlock filenameText = new TextBlock { Text = newFileName };
                filenameText.Foreground = Brushes.White;
                filenameText.HorizontalAlignment = HorizontalAlignment.Center;
                filenameText.TextTrimming = TextTrimming.CharacterEllipsis; // Abkürzung bei zu langen Namen

                // Erstellt ein TextBlock-Element für den Dateityp
                TextBlock filetypeText = new TextBlock { Text = file._Typ };
                filetypeText.HorizontalAlignment = HorizontalAlignment.Center;
                filetypeText.TextTrimming = TextTrimming.CharacterEllipsis; // Abkürzung bei zu langen Typen
                filetypeText.Foreground = Brushes.White;

                // Verwendet ein StackPanel, um die UI-Elemente vertikal anzuordnen
                StackPanel stackPanel = new StackPanel();
                stackPanel.HorizontalAlignment = HorizontalAlignment.Center;
                stackPanel.VerticalAlignment = VerticalAlignment.Center;
                stackPanel.Children.Add(iconImage);
                stackPanel.Children.Add(filenameText);
                stackPanel.Children.Add(filetypeText);

                // Verwendet eine Viewbox, um die Skalierung sicherzustellen
                Viewbox viewbox = new Viewbox();
                viewbox.Stretch = Stretch.Uniform; // Skaliert gleichmäßig
                viewbox.Child = stackPanel;

                // Fügt die Viewbox zur ersten Zeile hinzu
                Grid.SetRow(viewbox, 0);
                Grid.SetColumn(viewbox, 0);
                Grid.SetColumnSpan(viewbox, 1);
                grid.Children.Add(viewbox);

                // Erstellt den Button mit dem Tag file._Path
                Button button = new Button();
                button.Tag = file._Path;
                button.Background = Brushes.Transparent;
                button.BorderThickness = new Thickness(0);
                button.Width = double.NaN; // Automatische Breite
                button.Height = double.NaN; // Automatische Höhe
                button.HorizontalAlignment = HorizontalAlignment.Stretch;
                button.VerticalAlignment = VerticalAlignment.Stretch;
                button.MouseDoubleClick += Button_MouseDoubleClick;
                button.PreviewMouseLeftButtonDown += Button_PreviewMouseLeftButtonDown;
                button.Opacity = 0.2; //macht den button unsichtbar
                CreateButtonContextMenu(button);
                Grid.SetRow(button, 0);
                Grid.SetColumn(button, 0);
                Grid.SetColumnSpan(button, 1);
                grid.Children.Add(button);
                button.Style = (Style)FindResource("ItemButtonStyle");
                button.Cursor = Cursors.Hand; //Hand cursor wenn man drüber hovert

                // Überprüft ob die Dateiendungen angezeigt werden sollen
                if (!SettingsWindow.ShowFileExtension())
                    filetypeText.Visibility = Visibility.Hidden;

                // Fügt das Grid zum UniformGserid hinzu
                grid.HorizontalAlignment = HorizontalAlignment.Stretch;
                grid.VerticalAlignment = VerticalAlignment.Stretch;

                grid.Tag = file._Path;
                return grid;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return null;
        }
        #endregion

        // ContextMenu Erstellung und Handharbung
        #region
        // Erstellt das ContextMenu dür einen Button
        private void CreateButtonContextMenu(Button button) 
        {
            ContextMenu contextMenu = new ContextMenu();
            TextBox renameTextBox;

            MenuItem renameMenuItem = new MenuItem();
            renameMenuItem.Header = "Rename";
            renameMenuItem.Tag = button.Tag.ToString();

            renameTextBox = new TextBox()
            {
                Width = 80,
                Height = 20,
            };
            renameTextBox.LostFocus += (s, e) => { renameMenuItem.Tag = renameTextBox.Text; }; // ChatGPT
            renameMenuItem.Click += (s, e) => Rename_Click(s, e, renameTextBox.Text, button.Tag.ToString()); // ChatGPT

            MenuItem subMenu = new MenuItem { Header = renameTextBox };
            renameMenuItem.Items.Add(subMenu);
            Image renameIcon = new Image();
            renameIcon.Source = new BitmapImage(new Uri($"{resourcesFolder}\\rename.png", UriKind.Relative));
            renameMenuItem.Icon = renameIcon;

            renameMenuItem.SubmenuOpened += (s, e) => { subMenu.IsSubmenuOpen = true; }; // ChatGPT

            renameMenuItem.MouseEnter += (s, e) => { renameTextBox.Visibility = Visibility.Visible; }; // ChatGPT
            renameMenuItem.MouseLeave += (s, e) => { renameTextBox.Visibility = Visibility.Collapsed; }; // ChatGPT

            MenuItem deleteMenuItem = new MenuItem();
            deleteMenuItem.Header = "Delete";
            deleteMenuItem.Click += Delete_Click;
            deleteMenuItem.Tag = button.Tag.ToString();

            Image deleteIcon = new Image();
            deleteIcon.Source = new BitmapImage(new Uri($"{resourcesFolder}\\bin.png", UriKind.Relative));
            deleteMenuItem.Icon = deleteIcon;


            contextMenu.Items.Add(renameMenuItem);
            contextMenu.Items.Add(deleteMenuItem);

            button.ContextMenu = contextMenu;
        }
        // Überprüft ob ein ContextMenu offen ist
        public static bool IsContextMenuOpen()
        {
            foreach (Window window in Application.Current.Windows)
            {
                // Überprüfen Sie alle offenen Fenster auf geöffnete ContextMenus
                if (IsContextMenuOpenInVisualTree(window))
                {
                    return true;
                }
            }
            return false;
        }
        // Überprüft ob ein ContextMenu von der WPF App offen ist
        private static bool IsContextMenuOpenInVisualTree(DependencyObject parent)
        {
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++) // ChatGPT
            {
                DependencyObject child = VisualTreeHelper.GetChild(parent, i); // ChatGPT

                // Check if the child is a FrameworkElement, which includes controls that can have a ContextMenu
                if (child is FrameworkElement fe && fe.ContextMenu != null && fe.ContextMenu.IsOpen) // ChatGPT
                {
                    return true;
                }

                // Überprüft rekursiv alle untergeordneten Elemente
                if (IsContextMenuOpenInVisualTree(child))
                {
                    return true;
                }
            }

            return false;
        }
        #endregion

        // Window aktuallisierungs Methoden
        #region

        // Aktualisiert ob das Window sichtbar seien soll
        private static async void OpenIfShould()
        {
            if (CursorClasses.IsAtTop() | mouseInWindow | IsContextMenuOpen())
                shouldOpen = true;
            else
                shouldOpen = false;
            // Bestimmt nach wie vielen Millisekunden wiederholt weden soll 
            await Task.Delay(50);
            OpenIfShould();
        }

        // Aktualisiert die sichtbarkeit der Windows
        private async void RunWindow()
        {
            if (shouldOpen)
            {
                Show();
                isWindowOpen = true;
                await SlideInAnimation();
            }
            else
            {
                if (isWindowOpen)
                {
                    await SlideOutAnimation();
                    isWindowOpen = false;
                    Hide();
                }
                else
                    // Bestimmt nach wie vielen Millisekunden wiederholt weden soll 
                    await Task.Delay(50);
            }
            ButtonShow();
            RunWindow();
        }

        // Stellt die Button ein ob diese zu sehen sind
        private void ButtonShow()
        {
            // Back Button
            if (gridSite == 0)
            {
                back_Button.IsEnabled = false;
                back_Button.Visibility = Visibility.Hidden;
            }
            else
            {
                back_Button.IsEnabled = true;
                back_Button.Visibility = Visibility.Visible;
            }

            // Next Button
            if (filesInFolder.Count <= gridCells * (gridSite + 1))
            {
                next_Button.IsEnabled = false;
                next_Button.Visibility = Visibility.Hidden;
            }
            else
            {
                next_Button.IsEnabled = true;
                next_Button.Visibility = Visibility.Visible;
            }
        }
        #endregion

        // Enter und Leave events
        #region
        // Überprüft ob die Maus das Fenster verlassen hat
        private void Window_MouseLeave(object sender, MouseEventArgs e)
        {
            shouldOpen = false;
            mouseInWindow = false;
        }
        // Überprüft ob die Maus das Fenster betreten hat
        private void Window_MouseEnter(object sender, MouseEventArgs e)
        {
            mouseInWindow = true;
        }
        // Überprüft ob die Maus das Fenster mit Darg betreten hat
        private void Window_DragEnter(object sender, DragEventArgs e)
        {
            mouseInWindow = true;
        }
        // Überprüft ob die Maus das Fenster mit Darg verlassen hat
        private void Window_DragLeave(object sender, DragEventArgs e)
        {
            shouldOpen = false;
            mouseInWindow = false;
        }
        #endregion

        // Drop verarbeitung
        #region
        // Verarbeitet den gedropten inhalt
        private async void Window_Drop(object sender, DragEventArgs e)
        {
            watcher.Stop();
            if (e.Data.GetDataPresent(DataFormats.FileDrop)) // ChatGPT
            {
                string[] items = (string[])e.Data.GetData(DataFormats.FileDrop);
                foreach (string item in items)
                {
                    if (Directory.Exists(item))
                    {
                        int lastSlashIndex = item.LastIndexOf('\\');
                        await HandleFolderDrop(item, fileFolder + "\\" + item.Substring(lastSlashIndex + 1));
                    }
                    else if (File.Exists(item))
                    {
                        await HandleFileDrop(new string[] { item }, fileFolder);
                    }
                }
            }

            if (e.Data.GetDataPresent(DataFormats.Text))
            {
                string text = (string)e.Data.GetData(DataFormats.Text);
                byte[] bytes = Encoding.Default.GetBytes(text); // ChatGPT
                text = Encoding.UTF8.GetString(bytes); // ChatGPT
                HandleTextDrop(text);
            }
            LoadFiles();
            watcher.Start();
        }

        // Verarbeitet Ordner weiter
        private async static Task HandleFolderDrop(string sourceDir, string targetDir)
        {
            try
            {
                DirectoryInfo soudir = new DirectoryInfo(sourceDir);
                string testDir = $"{tempFolderPath}\\{soudir.Name}";

                if (testDir == soudir.FullName & !deleteAfterDrag)
                {
                    await Task.Delay(100);
                    DirectoryCopy(sourceDir, targetDir);
                }
                else
                {
                    DirectoryCopy(sourceDir, targetDir);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Verarbeitet Dateien weiter
        private async static Task HandleFileDrop(string[] filePath, string folder)
        {
            NewDirectory();
            for (int i = 0; i < filePath.Length; i++)
            {
                // Überprüft ob die datei aus dem Window kommt
                string newFilePath = $"{folder}/{Path.GetFileName(filePath[i])}";
                string oldFileFolder = $"{Path.GetDirectoryName(filePath[i])}";
                if (oldFileFolder == tempFolderPath & deleteAfterDrag)
                {
                    await Task.Delay(100);
                    File.Copy(filePath[i], newFilePath);
                }
                // Macht das Normale File Handling
                else if (!File.Exists(newFilePath))
                {
                    try
                    {
                        File.Copy(filePath[i], newFilePath);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }

        // Speichet text in einer txt Datei
        private static void HandleTextDrop(string text)
        {
            NewDirectory();
            try
            {
                string sanitizedText = text.Replace("\r\n", "_").Replace("\n", "_").Replace("\r", "_"); // ChatGPT
                string fileName = Regex.Replace(sanitizedText.Substring(0, maxFileName), @"[\/?:*""<>|]", "_"); // ChatGPT
                string filePath = $"{fileFolder}/{fileName}.txt";
                if (File.Exists(filePath))
                {
                    MessageBox.Show("File already exists");
                }
                else
                {
                    using (StreamWriter writer = new StreamWriter(filePath, false, Encoding.UTF8)) // ChatGPT
                    {
                        writer.Write(text);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Erstellt ein neues Folder wenn benötigt
        private static void NewDirectory()
        {
            if (!Directory.Exists(fileFolder))
            {
                try
                {
                    DirectoryInfo dir = Directory.CreateDirectory(fileFolder);
                    MessageBox.Show($"{dir} wurde Erstellt");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        #endregion

        // Window Animationen
        #region
        private async Task SlideInAnimation() 
        {
            DoubleAnimation slideInAnimation = new DoubleAnimation();
            slideInAnimation.From = Top;
            slideInAnimation.To = 0;
            slideInAnimation.Duration = TimeSpan.FromSeconds(0.2);
            BeginAnimation(TopProperty, slideInAnimation);
            await Task.Delay(slideInAnimation.Duration.TimeSpan);
        }

        private async Task SlideOutAnimation() 
        {
            DoubleAnimation slideOutAnimation = new DoubleAnimation();
            slideOutAnimation.From = Top;
            slideOutAnimation.To = -height;
            slideOutAnimation.Duration = TimeSpan.FromSeconds(0.2);
            slideOutAnimation.Completed += (s, e) => { Visibility = Visibility.Collapsed; }; // ChatGPT
            BeginAnimation(TopProperty, slideOutAnimation);
            await Task.Delay(slideOutAnimation.Duration.TimeSpan);
        }
        #endregion

        // Click events
        #region
        // Drag verarbeitung (Regelt das Rausziehen der File)
        private async void Button_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            await Task.Delay(200);
            if (e.ClickCount > 1)
            {
                e.Handled = true;
                return;
            }
            else
            {
                Application.Current.Dispatcher.Invoke(() => // ChatGPT
                {
                    watcher.Stop();

                    Button button = sender as Button;
                    if (button != null && button.Tag is string filePath)
                    {
                        SavedFile check = new SavedFile(filePath);
                        string tempPath;
                        DataObject data = new DataObject();

                        if (check._IsFolder)
                        {
                            DirectoryInfo dir = new DirectoryInfo(filePath);
                            tempPath = Path.Combine(tempFolderPath, dir.Name);
                            DirectoryCopy(filePath, tempPath);
                            data.SetData(DataFormats.FileDrop, new string[] { tempPath }); // ChatGPT
                        }
                        else
                        {
                            if (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl))
                            {
                                if (Path.GetExtension(filePath).Equals(".txt", StringComparison.OrdinalIgnoreCase))
                                {
                                    string fileContent = File.ReadAllText(filePath, Encoding.UTF8);
                                    data.SetData(DataFormats.StringFormat, fileContent); // ChatGPT
                                }
                            }
                            else
                            {
                                tempPath = Path.Combine(tempFolderPath, Path.GetFileName(filePath));
                                File.Copy(filePath, tempPath, true);
                                data.SetData(DataFormats.FileDrop, new string[] { tempPath }); // ChatGPT
                            }
                        }

                        DragDrop.DoDragDrop(button, data, DragDropEffects.Copy); // ChatGPT

                        watcher.Start();

                        deleteAfterDrag = SettingsWindow.ReturnDeleteAfterDrag();
                        if (deleteAfterDrag)
                        {
                            if (check._IsFolder)
                            {
                                Directory.Delete(filePath, true);
                            }
                            else
                            {
                                File.Delete(filePath);
                            }
                        }
                    }
                });
            }
        }

        // Ändert die werte so das eine neue "Seite" Entsteht
        private void next_Click(object sender, RoutedEventArgs e)
        {
            gridSite += gridCells;
            LoadFiles();
        }
        // Ändert die werte so das eine "Seite" zurück gegangen wird
        private void back_Click(object sender, RoutedEventArgs e)
        {
            if (gridSite != 0)
            {
                gridSite -= gridCells;
                LoadFiles();
            }
        }

        // Löscht die Datei wenn auf Delete geklickt wird
        private void Delete_Click(object sender, RoutedEventArgs e) 
        {
            try
            {
                MenuItem mi = sender as MenuItem;

                if (Directory.Exists(mi.Tag.ToString()))
                    Directory.Delete(mi.Tag.ToString(), true);
                else if (File.Exists(mi.Tag.ToString()))
                    File.Delete(mi.Tag.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        
        // Öffnet die Datei/Ordner wenn doppelt Geklickt wird
        private async void Button_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                Button button = sender as Button;
                SavedFile file = new SavedFile(button.Tag.ToString());

                string filePath = button.Tag.ToString();
                DirectoryInfo dir = new DirectoryInfo(filePath);
                string tempDirPath = Path.Combine(tempFolderPath, dir.Name);
                string newPath = $"{fileFolder}/{Path.GetFileName(filePath)}";

                //await Task.Delay(40);
                //if (deleteAfterDrag)
                //    if (file._IsFolder)
                //        if (Directory.Exists(newPath))
                //        {
                //            DirectoryCopy(tempDirPath, newPath);
                //        }
                //        else
                //        if (File.Exists(newPath))
                //        {
                //            File.Move(tempDirPath, newPath);
                //        }

                //await Task.Delay(200);
                Process.Start(new ProcessStartInfo(button.Tag.ToString()) { UseShellExecute = true }); // ChatGPT
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        // Ändert den Namen von einem Path
        private void Rename_Click(object sender, RoutedEventArgs e, string newName, string oldName)
        {
            try
            {
                MenuItem mi = sender as MenuItem;

                SavedFile check = new SavedFile(oldName);
                int newLength = maxFileName;


                if (newName.Length < maxFileName)
                    newLength = newName.Length;

                newName = Regex.Replace(newName.Substring(0, newLength), @"[\/?:*""<>|]", "_");
                newName = newName.Replace("\r\n", "_").Replace("\n", "_").Replace("\r", "_");
                string newNamePath = fileFolder + "/" + newName;

                if (!check._IsFolder)
                {
                    if (!File.Exists(newNamePath))
                    {
                        string fileTyp = Path.GetExtension(check._Path);
                        string newFilePath = newNamePath + fileTyp;

                        File.Move(check._Path, newFilePath);
                    }
                    else
                        MessageBox.Show("File already exists");
                }
                else
                {
                    if (!Directory.Exists(newNamePath))
                        Directory.Move(check._Path, newNamePath);
                    else
                        MessageBox.Show("Directory already exists");
                }
                LoadFiles();
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
        }

        // Öffnet die Einstellungen wenn Geklickt wird
        private void OnSettingsClicked(object sender, RoutedEventArgs e)
        {
            App.OpenSettings();
        }
        #endregion

        // Kopiert einen Ordner inklusive Unterordner
        private static void DirectoryCopy(string sourceDir, string targetDir)
        {
            if (!Directory.Exists(targetDir))
            {
                Directory.CreateDirectory(targetDir);
            }

            // Holt sich die Dateien im Quellordner
            string[] files = Directory.GetFiles(sourceDir);

            // Kopiert jeden Datei ins Zielordner
            foreach (string file in files)
            {
                string fileName = Path.GetFileName(file);
                string destFile = Path.Combine(targetDir, fileName);
                File.Copy(file, destFile, true);
            }

            // Holt sich die Unterordner im Quellordner
            string[] subdirectories = Directory.GetDirectories(sourceDir);

            // Kopiert jeden Unterordner in denn Zielordner (rekursiv)
            foreach (string subdir in subdirectories)
            {
                int lastSlashIndex = subdir.LastIndexOf('\\');
                string destSubDir = Path.Combine(targetDir, subdir.Substring(lastSlashIndex + 1));
                DirectoryCopy(subdir, destSubDir);
            }
        }
    }
}