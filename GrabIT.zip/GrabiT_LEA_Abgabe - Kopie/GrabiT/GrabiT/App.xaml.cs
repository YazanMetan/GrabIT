﻿using System;
using System.Drawing;
using System.Windows;
using Forms = System.Windows.Forms;

namespace GrabiT 
{
    /// <summary>
    /// Interaktionslogik für "App.xaml"
    /// </summary>
    public partial class App : Application 
   {
        private readonly Forms.NotifyIcon _notifyIcon;
        private static bool isSettingsWindowOpen = false;
        private readonly static string folder = "Resources";

        public App() 
        {
            _notifyIcon = new Forms.NotifyIcon();
        }

        // Stellt die Icons vom Systemtray ein
        protected override void OnStartup(StartupEventArgs e) 
        {
            _notifyIcon.Icon = new Icon($"{folder}\\icon.ico");
            _notifyIcon.Text = "Grab iT";
            _notifyIcon.Visible = true;

            _notifyIcon.ContextMenuStrip = new Forms.ContextMenuStrip();
            _notifyIcon.ContextMenuStrip.Items.Add("Settings", Image.FromFile($"{folder}\\settings.png"), OnSettingsClicked);
            _notifyIcon.ContextMenuStrip.Items.Add("Exit", Image.FromFile($"{folder}\\exit.png"), OnExitClicked);
        }

        // Wenn auf Setting geklickt wird, werden die Settings geöffnet
        private void OnSettingsClicked(object sender, EventArgs e) 
        {
            OpenSettings();
        }

        // Überprüft ob die Settings geöffnet werden können und öffnet es ggf.
        public static void OpenSettings()
        {
            if (!isSettingsWindowOpen)
            {
                SettingsWindow settingsWindow = new SettingsWindow();
                settingsWindow.Show();
                isSettingsWindowOpen = true;
            }
        }

        // Verlässt die Anwendung wenn der Close-Button gedrückt wird
        private void OnExitClicked(object sender, EventArgs e) 
        {
            Current.Shutdown();
        }

        // Löscht das Systemtray Icon wenn die Anwendung geschlossen wird
        protected override void OnExit(ExitEventArgs e) 
        {
            _notifyIcon.Dispose();
        }

        // Gibt den zustand des SettingWindows zurück
        public static bool GetIsSettingsWindowOpen() 
        {
            return isSettingsWindowOpen;
        }

        // Ändert denn zustand auf true
        public static void SetIsSettingsWindowOpen(bool isOpen) 
        {
            isSettingsWindowOpen = isOpen;
        }
    }
}
