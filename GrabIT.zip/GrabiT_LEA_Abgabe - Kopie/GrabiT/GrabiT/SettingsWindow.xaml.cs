﻿using System;
using System.Windows;
using System.Windows.Input;
using System.IO;
using IWshRuntimeLibrary;
using File = System.IO.File;
using Path = System.IO.Path;
using System.Windows.Controls;

namespace GrabiT 
{
    /// <summary>
    /// Interaktionslogik für SettingsWindow.xaml
    /// </summary>
    public partial class SettingsWindow : Window 
    {
        // Liest die Einstellungen und gibt Standard werte
        static bool startOnStartup = ConfigEdit.ReadBool("StartOnStartup=", false);
        static double scale = ConfigEdit.ReadDouble("Scale=", 1.5);
        static string folder = ConfigEdit.ReadString("Folder=", "Files");
        static bool isSettingsWindowOpen = App.GetIsSettingsWindowOpen();
        internal static double OpenWindowAtHeightToScreenRatio = ConfigEdit.ReadDouble("OpenWindowAtHeightToScreenRatio=", 0.01);
        static bool deleteAfterDrag = ConfigEdit.ReadBool("DeleteAfterDrag=", false);
        static bool showFileExtension = ConfigEdit.ReadBool("ShowFileExtension=", true);
        const string startupFolder = "\\Microsoft\\Windows\\Start Menu\\Programs\\Startup\\GrabiT.lnk";


        public SettingsWindow() 
        {
            InitializeComponent();
            LoadSettings();
        }

        // Eisntellung ausgebe
        #region
        public static bool ShowFileExtension()
        { return showFileExtension; }
        public static bool ReturnDeleteAfterDrag()
        { return deleteAfterDrag; }
        public static double ReturnScale()
        { return scale;}
        public static string ReturnFolder()
        {  return folder;}
        #endregion

        // Apply settings
        #region
        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
            App.SetIsSettingsWindowOpen(false);

        }
        private void UpdateSettingValues()
        {
            ConfigEdit.WriteDouble("Scale=", scale);
            ConfigEdit.WriteBool("StartOnStartup=", startOnStartup);
            ConfigEdit.WriteDouble("OpenWindowAtHeightToScreenRatio=", OpenWindowAtHeightToScreenRatio);
            ConfigEdit.WriteBool("DeleteAfterDrag=", deleteAfterDrag);
            ConfigEdit.WriteBool("ShowFileExtension=", showFileExtension);

        }

        private void LoadSettings() 
        {
            ScaleSlider.Value = ConfigEdit.ReadDouble("Scale=", 1.5);
            OpenWindowAtHeightToScreenRatioSlider.Value = ConfigEdit.ReadDouble("OpenWindowAtHeightToScreenRatio=", 0.01);
            StartupCheckBox.IsChecked = ConfigEdit.ReadBool("StartOnStartup=", false);
            DeleteAfterDragCheckBox.IsChecked = ConfigEdit.ReadBool("DeleteAfterDrag=", false);
            ShowFileExtentionCheckBox.IsChecked = ConfigEdit.ReadBool("ShowFileExtension=", true);
            MakeShortcutIfNeeded();
        }

        private void Apply_Click(object sender, RoutedEventArgs e)
        {
            EnableAndDisableStartup();
            EnableAndDisableDeleteAfterDrag();
            EnableAndDisableShowFileExtention();
            UpdateSettingValues();
            MainWindow.ApplyNewSettingsToWindow();
            
        }
        #endregion

        // Slider
        #region
        // Ändert denn Wert für das Größen verhältniss vom Fenster
        private void ScaleSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            scale = Math.Round(ScaleSlider.Value, 1);
        }

        // Ändert denn Wert für die höhe zum öffnen des Fensters vom Window 
        private void OpenWindowAtHeightToScreenRatio_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            OpenWindowAtHeightToScreenRatio = (OpenWindowAtHeightToScreenRatioSlider.Value / 100);
        }
        #endregion

        // Start on Starup
        #region

        // Gibt denn speicherort vom Shortcut zurück
        private string GetShortcut() 
        {
            return AppDomain.CurrentDomain.BaseDirectory + "GrabiT.lnk";
        }

        // Ändert ob das Programm beim Start gestartet werden soll
        private void EnableAndDisableStartup() 
        {
            if (StartupCheckBox.IsChecked == true)
            {
                startOnStartup = true;
                if (!File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + startupFolder))
                {
                    File.Copy(GetShortcut(), Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + startupFolder);
                }
            }
            else
            {
                startOnStartup = false;
                if (File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + startupFolder))
                {
                    File.Delete(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + startupFolder);
                }
            }
        }

        private void EnableAndDisableShowFileExtention() {
            if (ShowFileExtentionCheckBox.IsChecked == true) {
                showFileExtension = true;
            }
            else {
                showFileExtension = false;
            }
        }

        // Ändert den Wert für delete after drag
        private void EnableAndDisableDeleteAfterDrag()
        {
            if (DeleteAfterDragCheckBox.IsChecked == true)
            {
                deleteAfterDrag = true;
            }
            else
            {
                deleteAfterDrag = false;
            }
        }

        // Erstellt einen Shortcut wenn dieser nicht vorhanden ist
        private static void MakeShortcutIfNeeded()
        {
            try
            {
                string exePath = System.Reflection.Assembly.GetEntryAssembly().Location;
                string exeDirectory = Path.GetDirectoryName(exePath);

                if (!string.IsNullOrEmpty(exePath) && Directory.Exists(exeDirectory))
                {
                    var shell = new WshShell(); // ChatGPT

                    // Erstellt den neuen Shortcut
                    IWshShortcut shortcut = (IWshShortcut)shell.CreateShortcut(Path.Combine(exeDirectory, "GrabiT.lnk")); // ChatGPT

                    // Gibt dem Shortcut Parameta
                    shortcut.TargetPath = exePath;
                    shortcut.WorkingDirectory = AppDomain.CurrentDomain.BaseDirectory; // ChatGPT

                    shortcut.Save();

                }
                else
                {
                    MessageBox.Show("Invalid executable path or directory.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error creating shortcut: " + ex.Message);
            }
        }
        #endregion

        // Bewegt das Fenster wenn es Gezoge wird
        private void DragWindow(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }
    }
}