﻿using System.Runtime.InteropServices;
using System.Windows; // Or use whatever point class you like for the implicit cast operator


public class CursorGet
{
    /// <summary>
    /// Struct representing a point.
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    internal struct POINT
    {
        internal int X;
        internal int Y;

        internal static implicit operator Point(POINT point)
        {
            return new Point(point.X, point.Y);
        }


    }

    /// <summary>
    /// Retrieves the cursor's position, in screen coordinates.
    /// </summary>
    /// <see>See MSDN documentation for further information.</see>
    [DllImport("user32.dll")]
    internal static extern bool GetCursorPos(out POINT lpPoint);

    internal static Point GetCursorPosition()
    {
        POINT lpPoint;
        GetCursorPos(out lpPoint);
        // NOTE: If you need error handling
        // bool success = GetCursorPos(out lpPoint);
        // if (!success)

        return lpPoint;
    }
}
