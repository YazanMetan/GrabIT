﻿using System.Runtime.InteropServices;
using System.Windows;

namespace GrabiT
{
    internal class CursorClasses
    {
        // Quelle: https://stackoverflow.com/questions/1316681/getting-mouse-position-in-c-sharp Start
        [StructLayout(LayoutKind.Sequential)]
        public struct POINT
        {
            public int X;
            public int Y;

            public static implicit operator Point(POINT point)
            {
                return new Point(point.X, point.Y);
            }
            public override string ToString()
            {
                return $"X:{X}, Y:{Y}";
            }

            public override bool Equals(object obj)
            {
                POINT p = (POINT)obj;

                if (X == p.X && Y == p.Y) return true;
                return false;
            }

            public override int GetHashCode()
            {
                return base.GetHashCode();
            }
        }

        [DllImport("user32.dll")]
        public static extern bool GetCursorPos(out POINT lpPoint);

        public static Point GetCursorPosition()
        {
            POINT lpPoint;
            GetCursorPos(out lpPoint);
            // NOTE: If you need error handling
            // bool success = GetCursorPos(out lpPoint);
            // if (!success)

            return lpPoint;
        }
        // Quelle: https://stackoverflow.com/questions/1316681/getting-mouse-position-in-c-sharp Stop

        public static bool IsAtTop()
        {
            double heightToOpen = SystemParameters.PrimaryScreenHeight * SettingsWindow.OpenWindowAtHeightToScreenRatio;
            Point cursorPos = GetCursorPosition();
            if (cursorPos.Y <= heightToOpen)
                return true;
            return false;
        }
    }
}
