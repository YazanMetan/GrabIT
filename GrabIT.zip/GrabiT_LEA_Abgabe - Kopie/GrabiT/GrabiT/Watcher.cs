﻿using System;
using System.IO;

namespace GrabiT
{
    // ChatGPT Start
    internal class Watcher
    {
        private FileSystemWatcher fileWatcher;
        private string folderPath;

        public event EventHandler<FileChangedEventArgs> FileChanged;

        public Watcher(string folderPath)
        {
            this.folderPath = folderPath;
        }

        public void Start()
        {
            if (!Directory.Exists(folderPath))
            {
                throw new DirectoryNotFoundException($"The specified folder '{folderPath}' does not exist.");
            }

            // Create a new FileSystemWatcher
            fileWatcher = new FileSystemWatcher();
            fileWatcher.Path = folderPath;

            // Watch for changes in LastWrite and FileName events
            fileWatcher.NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.FileName;

            // Subscribe to the events
            fileWatcher.Changed += FileWatcher_Changed;
            fileWatcher.Created += FileWatcher_Created;
            fileWatcher.Deleted += FileWatcher_Deleted;
            fileWatcher.Renamed += FileWatcher_Renamed;

            // Enable the watcher
            fileWatcher.EnableRaisingEvents = true;
        }

        public void Stop()
        {
            // Disable and unsubscribe from the watcher events
            if (fileWatcher != null)
            {
                fileWatcher.EnableRaisingEvents = false;
                fileWatcher.Changed -= FileWatcher_Changed;
                fileWatcher.Created -= FileWatcher_Created;
                fileWatcher.Deleted -= FileWatcher_Deleted;
                fileWatcher.Renamed -= FileWatcher_Renamed;
                fileWatcher.Dispose();
            }
        }

        private void FileWatcher_Changed(object sender, FileSystemEventArgs e)
        {
            OnFileChanged(new FileChangedEventArgs(e));
        }

        private void FileWatcher_Created(object sender, FileSystemEventArgs e)
        {
            OnFileChanged(new FileChangedEventArgs(e));
        }

        private void FileWatcher_Deleted(object sender, FileSystemEventArgs e)
        {
            OnFileChanged(new FileChangedEventArgs(e));
        }

        private void FileWatcher_Renamed(object sender, RenamedEventArgs e)
        {
            OnFileChanged(new FileChangedEventArgs(e));
        }

        protected virtual void OnFileChanged(FileChangedEventArgs e)
        {
            MainWindow.LoadFiles();
        }
    }

    public class FileChangedEventArgs : EventArgs
    {
        public FileSystemEventArgs EventArgs { get; private set; }

        public FileChangedEventArgs(FileSystemEventArgs eventArgs)
        {
            EventArgs = eventArgs;
        }
    }
    // ChatGPT Stop
}
