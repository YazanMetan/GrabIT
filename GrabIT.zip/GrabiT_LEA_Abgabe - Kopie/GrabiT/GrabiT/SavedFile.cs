﻿using System;
using System.Drawing;
using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace GrabiT
{
    internal class SavedFile
    {
        private string _name;
        private string _typ;
        private string _path;
        private bool _isFolder;
        private ImageSource _icon;

        internal string _Name { get { return _name; } }
        internal string _Typ { get { return _typ; } }
        internal string _Path { get { return _path; } }
        internal bool _IsFolder { get { return _isFolder; } }
        internal ImageSource _Icon { get { return _icon; } }

        public SavedFile(string path)
        {
            _path = path;
            if (File.Exists(path))
            {
                _name = Path.GetFileNameWithoutExtension(_path);
                _typ = Path.GetExtension(_path);
                Icon icon = Icon.ExtractAssociatedIcon(_Path);
                Bitmap bitmap = icon.ToBitmap();


                // ChatGPT Start
                _icon = System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(
                    bitmap.GetHbitmap(),
                    IntPtr.Zero,
                    System.Windows.Int32Rect.Empty,
                    BitmapSizeOptions.FromEmptyOptions()
                );
                // ChatGPT Stop
            }
            else
            {
                DirectoryInfo dir = new DirectoryInfo( _path );
                _name = dir.Name;
                // ChatGPT Start
                var sourceBitmap = new BitmapImage(new Uri($"{MainWindow.resourcesFolder}\\FileIcon.png", UriKind.Relative));
                double scaleX = 32.0 / sourceBitmap.PixelWidth;
                double scaleY = 32.0 / sourceBitmap.PixelHeight;
                _icon = new TransformedBitmap(sourceBitmap, new ScaleTransform(scaleX, scaleY));
                // ChatGPT Stop
                _isFolder = true;
            }
        }

        public override bool Equals(object obj)
        {
            SavedFile savedFile = obj as SavedFile;
            return _Path == savedFile._Path;
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override string ToString()
        {
            return $"{_Path}";
        }
    }
}
